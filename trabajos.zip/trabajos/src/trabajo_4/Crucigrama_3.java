/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo_4;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Crucigrama_3 {
   
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("INGRESE LA PALABRA RAIZ: ");
        String palabraRaiz = entrada.nextLine();
        
        String[] palabras = new String[4];
        int i = 0;
        while (i < 4) {
            System.out.println("Ingrese una palabra: ");
            palabras[i] = entrada.nextLine();
            i++;
        }

        for (String palabra : palabras) {
            for (int j = 0; j < palabra.length(); j++) {
                if (palabraRaiz.contains(String.valueOf(palabra.charAt(j)))) {
                    System.out.println("La palabra " + palabra + " encaja en la palabra base");
                    break;
                }
            }
        }
    }
}


