/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo_4;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Crucigrama_1 {

  public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    System.out.println("INGRESE LA PALABRA RAIZ: ");
    String palabraRaiz = entrada.nextLine();
    System.out.println("INGRESE 4 PALABRAS MAS: ");
    String[] palabras = new String[4];
    for (int i = 0; i < 4; i++) {
      palabras[i] = entrada.nextLine();
    }

    
    for (String palabra : palabras) {
      for (int i = 0; i < palabra.length(); i++) {
        if (palabraRaiz.contains(String.valueOf(palabra.charAt(i)))) {
          System.out.println("La palabra " + palabra + " encaja en la palabra base");
          break;
        }
      }
    }
    }
}


    

