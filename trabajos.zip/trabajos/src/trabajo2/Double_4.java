/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo2;

import java.util.Arrays;
import java.util.HashMap;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Double_4 {

    public static void main(String[] args) {
        //generar la cantidad de numeros
        int numeroRandom = (int) Math.floor(Math.random() * 6 + 1);
        int[] arrMediana = new int[numeroRandom];
        int[] arrModa = new int[numeroRandom];
        double media;
        double suma = 0;
        double mediana;
        int mitad;
        double moda = 0;
        int maxValue = 0;

        Scanner entrada = new Scanner(System.in);
        System.out.println("Su numero aleatorio, es el: " + numeroRandom);

        int i = 0;
        for (int num : arrMediana) {
            System.out.println("INGRESE SU VALOR " + (i + 1) + ": ");
            num = entrada.nextInt();
            suma = suma + num;
            arrMediana[i] = num;
            arrModa[i] = num;
            i++;
        }

//   METODO DE MEDIANA
        Arrays.sort(arrMediana);
        mitad = arrMediana.length / 2;

        if (arrMediana.length % 2 == 0) {
            mediana = (arrMediana[mitad - 1] + arrMediana[mitad]) / 2;
        } else {
            mediana = arrMediana[mitad];
        }

//   METODO DE MODA
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int num : arrModa) {
            if (map.containsKey(num)) {
                int contador = map.get(num) + 1;
                map.put(num, contador);
                if (contador > maxValue) {
                    moda = num;
                    maxValue = contador;
                }
            } else {
                map.put(num, 1);
            }
        }

//   METODO DE MEDIA
        media = suma / numeroRandom;

        System.out.println("La media de sus numeros es: " + media);
        System.out.println("La mediana de sus numeros es: " + mediana);
        System.out.println("La moda de sus numeros es:" + moda);

    }
}
