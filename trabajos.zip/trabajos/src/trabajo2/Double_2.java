/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Double_2 {

    public static void main(String[] args) {
        //genera numero random
        int numeroRandom = (int) Math.floor(Math.random() * 38 + 1);
        Scanner entrada = new Scanner(System.in);

        double suma = 0;
        int contadorModa= 0;
        double moda = 0;
        int currentContador;
        double currentNumero;

        System.out.println("SU NUMERO ALEATORIO ES: " + numeroRandom);

        double[] numeros = new double[numeroRandom];

        int i = 0;
        do {
            System.out.println("INGRESE UN NUMERO "+(i+1)+":");
            numeros[i] = entrada.nextDouble();
            suma += numeros[i];
            i++;
        } while (i < numeroRandom);

        Arrays.sort(numeros);
        // METODO MEDIANA
        double mediana;
        if (numeroRandom % 2 == 0) {
            mediana = (numeros[numeroRandom / 2 - 1] + numeros[numeroRandom / 2]) / 2;
        } else {
            mediana = numeros[numeroRandom / 2];
        }
        // METODO DE MODA
        for (i = 0; i < numeroRandom; i++) {
            currentNumero = numeros[i];
            currentContador = 0;
            for (int j = 0; j < numeroRandom; j++) {
                if (numeros[j] == currentNumero) {
                    currentContador++;
                }
            }
            if (currentContador > contadorModa) {
                contadorModa = currentContador;
                moda = currentNumero;
            }
        }
        // METODO DE MEDIA
        double media = suma / numeroRandom;

        System.out.println("LA MEDIA ES: " + media);
        System.out.println("LA MEDIANA ES: " + mediana);
        System.out.println("LA MODA ES: " + moda);
    }
}
