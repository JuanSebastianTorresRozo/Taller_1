/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Double_3 {

    public static void main(String[] args) {
        //GENERA NUMEROS RANDOM DE LA ARRAY
        int numeroRandom = (int) Math.floor(Math.random() * 38 + 1);
        Scanner entrada = new Scanner(System.in);
        System.out.println("SU NUMERO RANDOM VA A SER :" + numeroRandom);
        int n = numeroRandom;
        int[] numeros = new int[numeroRandom];
        int i = 0;
        while (i < n) {
            System.out.print("INGRESE UN NUMERO " + (i + 1) + ":");
            numeros[i] = entrada.nextInt();
            i++;
        }
        // Cálculo de la mediana
        Arrays.sort(numeros);
        double mediana;
        if (n % 2 == 0) {
            mediana = (numeros[n / 2 - 1] + numeros[n / 2]) / 2.0;
        } else {
            mediana = numeros[n / 2];
        }
        

        // Cálculo de la media
        int suma = 0;
        for (int num : numeros) {
            suma += num;
        }
        double media= (double) suma / n;
       

        

        // Cálculo de la moda
        int cuentaMax = 0;
        int moda = numeros[0];
        int cuenta = 1;
        for (i = 1; i < n; i++) {
            if (numeros[i] == numeros[i - 1]) {
                cuenta++;
            } else {
                if (cuenta > cuentaMax) {
                    cuentaMax = cuenta;
                    moda = numeros[i - 1];
                }
                cuenta = 1;
            }
        }
         System.out.println("La media es: " + media);
        System.out.println("La mediana es: " + mediana);
        System.out.println("La moda es: " + moda);
    }
}
