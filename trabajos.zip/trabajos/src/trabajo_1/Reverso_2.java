/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo_1;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Reverso_2 {

    public static void main(String[] args) {
        Scanner palabras = new Scanner(System.in);
        int Tamaño = 0;
        String cadena ;
        String cadenaInvertida = "";

        System.out.println("DIGITE UNA CADENA DE TEXTO :");
        cadena = palabras.nextLine();

        Tamaño = cadena.length();

        while (Tamaño != 0) {
            cadenaInvertida += cadena.substring(Tamaño - 1, Tamaño);
            Tamaño--;

        }
        System.out.println("CADENA ACTUAL ES :" + cadena);
        System.out.println("CADENA INVERTIDA ES :" + cadenaInvertida);

    }

}
