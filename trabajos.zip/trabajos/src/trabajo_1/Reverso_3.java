/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo_1;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Reverso_3 {

    public static void main(String[] args) {
        Scanner palabras = new Scanner(System.in);
        int Tamaño = 0;
        String cadena;
        String cadenaInvertida = "";
        
         // Metodo para pedir la cadena de texto 
        System.out.println("DIGITE UNA CADENA DE TEXTO 2:");
        cadena = palabras.nextLine();

        Tamaño = cadena.length()-1;
        // Metodo para invertir la cadena de texto
        do {
            cadenaInvertida = cadenaInvertida + cadena.charAt(Tamaño);
            Tamaño = Tamaño - 1;
            
        } while (Tamaño >= 0);

        System.out.println("CADENA ACTUAL ES :" + cadena);
        System.out.println("CADENA INVERTIDA ES :" + cadenaInvertida);
    }

}
