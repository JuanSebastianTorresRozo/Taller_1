/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajo_1;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Reverso_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cadena = "";

        if (cadena.equals("")) {
            Scanner Palabras = new Scanner(System.in);
            System.out.print("Introduzca una cadena de texto: ");
            cadena = Palabras.nextLine();
        }
         
    }

    public static String InvertirCadena(String cadena) {
        String cadenaInvertida = "";
        for (int i = cadena.length() - 1; i >= 0; i--) {
            cadenaInvertida = cadenaInvertida + cadena.charAt(i);
        }
        return cadenaInvertida;
    }
}
