/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo_1;

import java.util.Scanner;

/**
 *
 * @author ROZO
 */
public class Reverso_4 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("INGRESE UNA CADENA DE TEXTO : ");
        String palabra = entrada.nextLine();

        char[] reverso = new char[palabra.length()];
        int j = 0;
        for (char c : palabra.toCharArray()) {
            reverso[j++] = c;
        }

        System.out.print("EL REVERSO DE LA PALABRA ES : ");
        for (int i = reverso.length - 1; i >= 0; i--) {
            System.out.print(reverso[i]);
        }

    }
}
